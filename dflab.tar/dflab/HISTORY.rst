.. :changelog:

History
-------

0.1.0 (2014-01-11)
---------------------

* First release on github. 
