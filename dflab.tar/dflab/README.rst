===============================
dflab
===============================

.. image:: https://badge.fury.io/py/dflab.png
    :target: http://badge.fury.io/py/dflab

.. image:: https://travis-ci.org/mgieles/dflab.png?branch=master
        :target: https://travis-ci.org/mgieles/dflab

.. image:: https://pypip.in/d/dflab/badge.png
        :target: https://pypi.python.org/pypi/dflab


DF based stuff

* Free software: BSD license
* Documentation: https://dflab.readthedocs.org.

Features
--------

* TODO
