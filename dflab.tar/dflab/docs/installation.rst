============
Installation
============

At the command line::

    $ git clone https://github.com/mgieles/dflab.git
    $ cd dflab
    $ python setup.py install

or::
    $ pip install -e ./ 

