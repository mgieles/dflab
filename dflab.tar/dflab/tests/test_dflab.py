#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_dflab
----------------------------------

Tests for `dflab` module.
"""

import unittest

from dflab import dflab


class TestDflab(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()
