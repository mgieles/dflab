# -*- coding: utf-8 -*-

__author__ = 'Mark Gieles, Alice Zocchi'
__email__ = 'm.gieles@surrey.ac.uk, a.zocchi@surrey.ac.uk'
__version__ = '0.1.0'

from .limepy import limepy
